<?php
$conn=mysqli_connect("localhost","root","","feedtest")or die(mysqli_error());
?>